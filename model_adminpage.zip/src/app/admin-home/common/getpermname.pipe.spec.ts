import { GetpermnamePipe } from './getpermname.pipe';

describe('GetpermnamePipe', () => {
  it('create an instance', () => {
    const pipe = new GetpermnamePipe();
    expect(pipe).toBeTruthy();
  });
});
