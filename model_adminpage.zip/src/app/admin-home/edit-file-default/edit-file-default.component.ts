import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-file-default',
  templateUrl: './edit-file-default.component.html',
  styleUrls: ['./edit-file-default.component.scss']
})
export class EditFileDefaultComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
