import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-img-list',
  templateUrl: './edit-img-list.component.html',
  styleUrls: ['./edit-img-list.component.scss']
})
export class EditImgListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
