import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-model-default',
  templateUrl: './edit-model-default.component.html',
  styleUrls: ['./edit-model-default.component.scss']
})
export class EditModelDefaultComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
