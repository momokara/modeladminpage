import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-photographer',
  templateUrl: './edit-photographer.component.html',
  styleUrls: ['./edit-photographer.component.scss']
})
export class EditPhotographerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
