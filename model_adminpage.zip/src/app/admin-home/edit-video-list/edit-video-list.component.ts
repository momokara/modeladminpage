import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-video-list',
  templateUrl: './edit-video-list.component.html',
  styleUrls: ['./edit-video-list.component.scss']
})
export class EditVideoListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
