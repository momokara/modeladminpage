import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editfield',
  templateUrl: './editfield.component.html',
  styleUrls: ['./editfield.component.scss']
})
export class EditfieldComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
