import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-defalutpage',
  templateUrl: './defalutpage.component.html',
  styleUrls: ['./defalutpage.component.scss']
})
export class DefalutpageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
