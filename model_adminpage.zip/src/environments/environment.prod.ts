export const environment = {
  production: true,
  istest: false,
  baseurl: { baseherf: '/index/index/' }
};
